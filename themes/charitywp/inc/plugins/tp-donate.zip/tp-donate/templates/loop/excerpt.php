<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<div class="campaign_excerpt">

	<?php the_excerpt(); ?>

</div>