<?php

/**
 * cart title
 */
?>
<thead>
	<tr>
		<th class="donate_cart_item_name">
			<?php _e( 'Item name', 'tp-donate' ) ?>
		</th>
		<th class="donate_cart_item_amount">
			<?php _e( 'Item amount', 'tp-donate' ) ?>
		</th>
	</tr>
</thead>
