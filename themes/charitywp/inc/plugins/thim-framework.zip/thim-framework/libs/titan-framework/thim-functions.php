<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 * Description of thim-functions
 *
 * @author Tuannv
 */
require_once( TF_PATH . 'thim-class-meta-box.php' );
require_once( TF_PATH . 'thim-class-customizer-section.php' );
