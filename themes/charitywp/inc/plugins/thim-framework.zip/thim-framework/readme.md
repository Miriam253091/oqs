//version 1.5 27/01/2016
+ Update upload option to support svg format.(class-option-upload.php)

//version 1.6 03/02/2016
+ Improved import function.

//version 1.7 19/02/2016
+ Fixed required import demo.
+ Updated class Thim_Widget